# Pactos de ceniza / Pacts After the Fall

A real-time, browser-based party game prototype for 2–8 players. Players join a host’s room with a four-character code, receive private role information, investigate a crisis, negotiate, vote, see the consequences, and reflect on the AI concepts behind the story. Each device can choose English or Spanish independently.

Five missions are available: The Kestrel Quarantine, The Last Reactor, The Moving Veil, The Water Compact, and The Ghost Signal. Each mission unfolds through four linked decisions. Every stage offers four new, story-specific investigation actions as well as four verdict responses. Every verdict changes the shared measures and the context of the next crisis stage.

## Run it

1. Install Node.js 20 or newer on the host computer.
2. Open a terminal in this folder and run `node server.mjs`.
3. On the host computer, open `http://localhost:4173` and create a room.
4. For players on the same Wi-Fi network, share the host computer’s local network address with port `4173` (for example, `http://192.168.1.20:4173`) and the four-character room code.

The room server must stay running while people play. Rooms and messages live in server memory and disappear when the server stops. This prototype has no accounts or database. For players joining from different networks, deploy the Node server to a host that supports WebSockets and HTTPS; room state is held by one server process.

## Round flow

Crew assembly → four cycles of crisis update, four changing investigation actions, timed negotiation, private verdict, and consequence reveal → AI-system learning reveal → reflection → mandate reveal.

The learning reveal explains the fictional system’s objective, proxy data, uncertainty, gaps, and accountability. It connects those details to algorithm literacy, ethics, and critical thinking without declaring one moral answer correct.

Before each private verdict, players see the narrative trade-offs but no projected scores or measure changes. The server reveals the actual changes only after the vote resolves. Players select a response and then confirm their verdict. At the deadline, the option with the most submitted votes wins; a tie or no votes applies the announced fallback plan. The final review shows the full decision chain and the accumulated measures.

“The Moving Veil” explains the exclusion belt directly in its opening brief: it is a contaminated region where storms cause dangerous exposure and magnetic distortions that can disable vehicles. Its route, toll, and supply terms are also explained in plain language.
