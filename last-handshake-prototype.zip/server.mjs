import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { followUpRounds, initialFourthChoice, initialInvestigationActions } from './decision-rounds.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.join(here, 'public');
const port = Number(process.env.PORT || 4173);
const rooms = new Map();
const sockets = new Set();

const { missions, roles, agendas } = JSON.parse(fs.readFileSync(path.join(publicDir, 'missions.json'), 'utf8'));
for (const mission of missions) {
  const additionalChoice = initialFourthChoice(mission.id);
  if (additionalChoice) mission.options.push(additionalChoice);
  mission.actions = initialInvestigationActions(mission.id, mission.actions);
}
const scenarioById = new Map(missions.map(mission => [mission.id, mission]));
const roundsById = new Map(missions.map(mission => [mission.id, [null, ...followUpRounds(mission.id)]]));
function fallbackOption(room) {
  const options = currentScenario(room).options;
  return options.find(option => option.isFallback) || options.find(option => option.id === 'staged') || options[0];
}
function currentScenario(room) {
  const round = roundsById.get(room.scenario.id)?.[room.roundIndex];
  if (!round) return { ...room.scenario, roundTitle: room.scenario.title };
  const transition = room.lastDecisionType === 'contain'
    ? { en: 'After the previous decision, the response moved quickly, but people left outside the plan are asking for a voice.', es: 'Tras la decisión anterior, la respuesta avanzó rápido, pero quienes quedaron fuera del plan piden tener voz.' }
    : room.lastDecisionType === 'override'
      ? { en: 'The previous decision shared control with affected people. That built more support, but cost time and coordination.', es: 'La decisión anterior compartió el control con las personas afectadas. Eso generó más apoyo, pero consumió tiempo y coordinación.' }
      : room.lastDecisionType === 'protect'
        ? { en: 'The previous decision protected the people facing the greatest immediate harm, shifting part of the remaining risk to others.', es: 'La decisión anterior protegió a quienes enfrentaban el daño más inmediato y trasladó parte del riesgo restante a otras personas.' }
      : { en: 'The previous decision paused for verification. The crew has more time to check assumptions, but the delay has used scarce resources.', es: 'La decisión anterior se detuvo para verificar. La tripulación puede comprobar supuestos, pero la demora consumió recursos escasos.' };
  return { ...room.scenario, roundTitle: round.title, briefing: { en: `${transition.en}\n\n${round.briefing.en}`, es: `${transition.es}\n\n${round.briefing.es}` }, signals: round.signals, options: round.options, actions: round.actions };
}

function frame(opcode, data = Buffer.alloc(0)) {
  const payload = Buffer.isBuffer(data) ? data : Buffer.from(data);
  let header;
  if (payload.length < 126) { header = Buffer.from([0x80 | opcode, payload.length]); }
  else if (payload.length < 65536) { header = Buffer.alloc(4); header[0] = 0x80 | opcode; header[1] = 126; header.writeUInt16BE(payload.length, 2); }
  else { header = Buffer.alloc(10); header[0] = 0x80 | opcode; header[1] = 127; header.writeBigUInt64BE(BigInt(payload.length), 2); }
  return Buffer.concat([header, payload]);
}
function send(client, value) { if (!client.closed) client.socket.write(frame(1, JSON.stringify(value))); }
function safeRoom(room, client) {
  const view = currentScenario(room);
  const { clues: _clues, specials: _specials, concepts: _concepts, systemReveal: _systemReveal, actions, ...scenarioBase } = view;
  const publicScenario = {
    ...scenarioBase,
    options: scenarioBase.options.map(option => {
      const { alignment: _alignment, ...publicOption } = option;
      if (room.phase === 'consequences' || room.phase === 'debrief' || room.phase === 'reflection' || room.phase === 'finished') return publicOption;
      const { delta: _delta, ...withoutScore } = publicOption;
      return withoutScore;
    }),
    actions: Object.fromEntries(Object.entries(actions).map(([key, action]) => [key, { title: action.title, description: action.description }])),
    ...(room.phase === 'debrief' || room.phase === 'reflection' || room.phase === 'finished' ? { concepts: _concepts, systemReveal: _systemReveal } : {})
  };
  return {
    code: room.code, phase: room.phase, hostId: room.hostId, deadline: room.deadline, decisionReason: room.decisionReason,
    roundIndex: room.roundIndex, roundCount: 4, decisionHistory: room.decisionHistory,
    votesSubmitted: [...room.players.values()].filter(p => p.vote).length,
    scenario: publicScenario, tracks: room.tracks, actionCount: room.actionCount,
    selected: room.selected, winner: room.winner, events: room.events.slice(-16), chat: room.chat.slice(-24),
    reflections: room.reflections, lastDelta: room.lastDelta,
    players: [...room.players.values()].map(p => ({ id: p.id, name: p.name, role: p.role, connected: p.connected, ready: p.ready, hasActed: p.hasActed, action: p.action, vote: p.id === client.id || room.phase === 'consequences' || room.phase === 'debrief' || room.phase === 'reflection' || room.phase === 'finished' ? p.vote : null, reflection: p.reflection, ...(p.id === client.id || room.phase === 'finished' ? { secret: p.secret, privateInfo: p.privateInfo, specialUsed: p.specialUsed } : {}), ...(room.phase === 'finished' ? { mandateMet: p.mandateMet } : {}) })),
    you: room.players.get(client.id) ? { id: client.id, secret: room.players.get(client.id).secret, privateInfo: room.players.get(client.id).privateInfo } : null
  };
}
function broadcast(room) { for (const c of sockets) if (c.room === room.code) send(c, { type: 'state', room: safeRoom(room, c) }); }
function addEvent(room, title, text) { room.events.push({ title, text, at: Date.now() }); }
function newCode() {
  let code;
  do { code = crypto.randomBytes(3).toString('hex').slice(0, 4).toUpperCase(); } while (rooms.has(code));
  return code;
}
function makeRoom(host, name, scenarioId) {
  const code = newCode();
  const room = { code, hostId: host.id, phase: 'lobby', scenario: scenarioById.get(scenarioId) || missions[0], players: new Map(), tracks: { safety: 2, trust: 2, autonomy: 2 }, actionCount: 0, evidenceSources: new Set(), selected: null, winner: null, decisionReason: null, deadline: null, events: [], chat: [], reflections: [], roundIndex: 0, decisionHistory: [], lastDelta: null };
  room.players.set(host.id, { id: host.id, name, role: null, connected: true, ready: true, hasActed: false, action: null, vote: null, reflection: '' });
  rooms.set(code, room); host.room = code; return room;
}
function startGame(room) {
  if (room.players.size < 2 || room.players.size > 8) return;
  const list = [...room.players.values()];
  const roleDeck = [...roles].sort(() => Math.random() - 0.5);
  const agendaDeck = [...agendas].sort(() => Math.random() - 0.5);
  const hiddenCount = list.length >= 7 ? 2 : 1;
  list.sort(() => Math.random() - 0.5).forEach((p, i) => {
    const role = roleDeck[i % roleDeck.length];
    p.role = role.name; p.privateInfo = { en: `${role.description.en} ${room.scenario.clues[i % room.scenario.clues.length].en}`, es: `${role.description.es} ${room.scenario.clues[i % room.scenario.clues.length].es}` }; p.clueIndex = i % room.scenario.clues.length; p.hasActed = false; p.vote = null; p.reflection = '';
    const agendaIndex = i % agendaDeck.length;
    const specialIndex = agendas.findIndex(agenda => agenda.id === agendaDeck[agendaIndex].id);
    p.secret = i < hiddenCount ? { ...agendaDeck[agendaIndex], special: room.scenario.specials[specialIndex] } : null; p.specialUsed = false;
  });
  room.phase = 'briefing'; room.events = []; room.chat = []; room.reflections = []; room.tracks = { safety: 2, trust: 2, autonomy: 2 }; room.actionCount = 0; room.evidenceSources.clear(); room.selected = null; room.winner = null; room.decisionReason = null; room.roundIndex = 0; room.decisionHistory = []; room.lastDelta = null; room.lastDecisionType = null;
  addEvent(room, { en: 'Emergency channel open', es: 'Canal de emergencia abierto' }, room.scenario.opening);
  broadcast(room);
}
function changePhase(room, next) {
  room.phase = next;
  if (next === 'negotiation') room.deadline = Date.now() + 90000;
  else if (next === 'vote') room.deadline = Date.now() + 45000;
  else room.deadline = null;
  if (next === 'investigation') addEvent(room, { en: 'Investigation window', es: 'Fase de investigación' }, { en: 'Inspect the system, verify an independent record, or ask affected residents.', es: 'Revisa el sistema, verifica un registro independiente o escucha a las personas afectadas.' });
  if (next === 'negotiation') addEvent(room, { en: 'Debate and negotiation', es: 'Debate y negociación' }, { en: 'Compare evidence and interests. Each player has 90 seconds to make a case or change their mind. This stage’s verdict comes next.', es: 'Comparen las pruebas y los intereses. Cada persona tiene 90 segundos para defender su postura o cambiar de opinión. Después registrarán el veredicto de esta etapa.' });
  if (next === 'vote') addEvent(room, { en: 'Final verdict', es: 'Veredicto final' }, { en: 'Choose one response and confirm your private vote. A tie or no votes applies the announced fallback plan.', es: 'Elijan una respuesta y confirmen su voto privado. Si hay empate o nadie vota, se aplica el plan de respaldo anunciado.' });
  if (next === 'consequences' && room.winner) {
    const choice = currentScenario(room).options.find(option => option.id === room.winner);
    room.lastDecisionType = choice.alignment || choice.id;
    room.lastDelta = {};
    for (const key of Object.keys(room.tracks)) {
      const before = room.tracks[key]; room.tracks[key] = Math.max(0, Math.min(5, before + choice.delta[key])); room.lastDelta[key] = room.tracks[key] - before;
    }
    room.decisionHistory.push({ roundIndex: room.roundIndex, choiceId: choice.id, alignment: choice.alignment || choice.id, name: choice.name, result: choice.result, tracks: { ...room.tracks }, delta: { ...room.lastDelta } });
    addEvent(room, { en: 'Choice in motion', es: 'La decisión está en marcha' }, choice.result);
  }
  if (next === 'debrief') addEvent(room, { en: 'What the system was doing', es: 'Qué hacía el sistema' }, room.scenario.systemReveal);
  if (next === 'finished') {
    for (const p of room.players.values()) {
      const mandate = p.secret?.id;
      p.mandateMet = mandate === 'continuity' ? room.decisionHistory.some(decision => decision.alignment === 'contain')
        : mandate === 'contract' ? room.decisionHistory.every(decision => decision.alignment !== 'override')
        : mandate === 'access' ? (p.specialUsed || room.evidenceSources.has('residents'))
        : mandate === 'evidence' ? room.evidenceSources.size >= 2 : null;
    }
  }
  broadcast(room);
}
function parseMessage(client, value) {
  let msg; try { msg = JSON.parse(value.toString()); } catch { return; }
  if (msg.type === 'create') {
    const name = String(msg.name || 'Commander').trim().slice(0, 20) || 'Commander';
    const room = makeRoom(client, name, msg.scenario); client.name = name; broadcast(room); return;
  }
  if (msg.type === 'join') {
    const code = String(msg.code || '').trim().toUpperCase(); const room = rooms.get(code);
    const name = String(msg.name || 'Crew member').trim().slice(0, 20) || 'Crew member';
    if (!room) { send(client, { type: 'error', message: 'That room code was not found. Check it and try again.' }); return; }
    if (room.phase !== 'lobby') { send(client, { type: 'error', message: 'This mission has already started.' }); return; }
    if (room.players.size >= 8) { send(client, { type: 'error', message: 'This room is full. The crew limit is eight.' }); return; }
    client.room = code; client.name = name;
    room.players.set(client.id, { id: client.id, name, role: null, connected: true, ready: true, hasActed: false, action: null, vote: null, reflection: '' });
    broadcast(room); return;
  }
  const room = rooms.get(client.room); if (!room) return;
  const player = room.players.get(client.id); if (!player) return;
  if (msg.type === 'start' && client.id === room.hostId && room.phase === 'lobby') startGame(room);
  if (msg.type === 'advance' && client.id === room.hostId) {
    let next = { briefing: 'investigation', investigation: 'negotiation', negotiation: 'vote', consequences: 'debrief', debrief: 'reflection', reflection: 'finished' }[room.phase];
    if (room.phase === 'consequences' && room.roundIndex < 3) {
      room.roundIndex++; room.phase = 'briefing'; room.winner = null; room.decisionReason = null; room.lastDelta = null; room.actionCount = 0;
      for (const p of room.players.values()) { p.hasActed = false; p.action = null; p.vote = null; }
      const nextScenario = currentScenario(room);
      addEvent(room, { en: `Decision ${room.roundIndex + 1} begins`, es: `Comienza la decisión ${room.roundIndex + 1}` }, nextScenario.briefing);
      broadcast(room); return;
    }
    if (room.phase === 'investigation' && [...room.players.values()].some(p => !p.hasActed)) return;
    if (next) changePhase(room, next);
  }
  if (msg.type === 'action' && room.phase === 'investigation' && !player.hasActed) {
    const result = currentScenario(room).actions[msg.action]; if (!result) return;
    player.hasActed = true; player.action = msg.action; room.actionCount++;
    room.evidenceSources.add(result.source || msg.action);
    addEvent(room, { en: `${player.name}: ${result.title.en}`, es: `${player.name}: ${result.title.es}` }, result.evidence); broadcast(room);
  }
  if (msg.type === 'special' && ['investigation', 'negotiation'].includes(room.phase) && player.secret && !player.specialUsed) {
    player.specialUsed = true;
    if (player.secret.id === 'access') { player.action = 'residents'; room.evidenceSources.add('residents'); }
    if (player.secret.id === 'evidence') room.evidenceSources.add('independent-audit');
    addEvent(room, { en: `${player.name} raises a stakeholder issue`, es: `${player.name} plantea un interés de una parte involucrada` }, player.secret.special); broadcast(room);
  }
  if (msg.type === 'chat' && ['investigation', 'negotiation', 'vote'].includes(room.phase)) {
    const text = String(msg.text || '').trim().slice(0, 400); if (!text) return;
    room.chat.push({ name: player.name, text, at: Date.now() }); broadcast(room);
  }
  if (msg.type === 'vote' && room.phase === 'vote' && !player.vote && currentScenario(room).options.some(option => option.id === msg.choice)) {
    player.vote = msg.choice;
    const votes = [...room.players.values()].filter(p => p.vote);
    if (votes.length === room.players.size) {
      const counts = Object.fromEntries(currentScenario(room).options.map(option => [option.id, votes.filter(p => p.vote === option.id).length]));
      const top = Math.max(...Object.values(counts));
      const tied = Object.keys(counts).filter(k => counts[k] === top);
      room.decisionReason = tied.length > 1 ? 'tie' : 'vote';
      room.winner = tied.length > 1 ? fallbackOption(room).id : tied[0];
      changePhase(room, 'consequences');
    } else broadcast(room);
  }
  if (msg.type === 'reflect' && room.phase === 'reflection') {
    const text = String(msg.text || '').trim().slice(0, 500); if (!text) return;
    player.reflection = text; room.reflections = [...room.players.values()].filter(p => p.reflection).map(p => ({ name: p.name, text: p.reflection })); broadcast(room);
  }
  if (msg.type === 'leave') { removeClient(client); }
}
function removeClient(client) {
  sockets.delete(client); client.closed = true;
  const room = rooms.get(client.room); if (!room) return;
  if (room.players.has(client.id)) room.players.delete(client.id);
  if (room.players.size === 0) rooms.delete(room.code);
  else {
    if (room.hostId === client.id) room.hostId = room.players.keys().next().value;
    broadcast(room);
  }
}

const mime = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml' };
const server = http.createServer((req, res) => {
  const pathname = decodeURIComponent(new URL(req.url, `http://${req.headers.host}`).pathname);
  if (pathname === '/missions.json') {
    res.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
    res.end(JSON.stringify({ missions: missions.map(({ id, title, pitch }) => ({ id, title, pitch })) })); return;
  }
  const requested = pathname === '/' ? '/index.html' : pathname;
  const file = path.resolve(publicDir, `.${requested}`);
  if (!file.startsWith(`${publicDir}${path.sep}`)) { res.writeHead(403).end(); return; }
  fs.readFile(file, (error, data) => {
    if (error) { res.writeHead(404).end('Not found'); return; }
    res.writeHead(200, { 'content-type': mime[path.extname(file)] || 'application/octet-stream', 'cache-control': 'no-store' }); res.end(data);
  });
});
server.on('upgrade', (req, socket) => {
  const key = req.headers['sec-websocket-key'];
  if (!key) { socket.destroy(); return; }
  const accept = crypto.createHash('sha1').update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
  socket.write(`HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ${accept}\r\n\r\n`);
  const client = { socket, id: crypto.randomUUID(), buffer: Buffer.alloc(0), room: null, closed: false };
  sockets.add(client);
  socket.on('data', chunk => {
    client.buffer = Buffer.concat([client.buffer, chunk]);
    while (client.buffer.length >= 2) {
      const b0 = client.buffer[0], b1 = client.buffer[1], opcode = b0 & 0x0f, masked = Boolean(b1 & 0x80);
      let length = b1 & 0x7f, offset = 2;
      if (length === 126) { if (client.buffer.length < 4) return; length = client.buffer.readUInt16BE(2); offset = 4; }
      else if (length === 127) { if (client.buffer.length < 10) return; length = Number(client.buffer.readBigUInt64BE(2)); offset = 10; }
      if (masked) offset += 4;
      if (client.buffer.length < offset + length) return;
      let payload = client.buffer.subarray(offset, offset + length);
      if (masked) { const mask = client.buffer.subarray(offset - 4, offset); payload = Buffer.from(payload); for (let i = 0; i < payload.length; i++) payload[i] ^= mask[i % 4]; }
      client.buffer = client.buffer.subarray(offset + length);
      if (opcode === 8) { socket.end(frame(8)); return; }
      if (opcode === 9) { socket.write(frame(10, payload)); continue; }
      if (opcode === 1) parseMessage(client, payload);
    }
  });
  socket.on('close', () => removeClient(client)); socket.on('error', () => removeClient(client));
});

setInterval(() => {
  const now = Date.now();
  for (const room of rooms.values()) {
    if (!room.deadline || room.deadline > now) continue;
    if (room.phase === 'negotiation') changePhase(room, 'vote');
    else if (room.phase === 'vote') {
      const votes = [...room.players.values()].filter(p => p.vote);
      if (!votes.length) { room.winner = fallbackOption(room).id; room.decisionReason = 'no-votes'; }
      else {
        const counts = Object.fromEntries(currentScenario(room).options.map(option => [option.id, votes.filter(p => p.vote === option.id).length]));
        const top = Math.max(...Object.values(counts)); const tied = Object.keys(counts).filter(k => counts[k] === top);
        room.decisionReason = tied.length > 1 ? 'tie' : 'vote';
        room.winner = tied.length > 1 ? fallbackOption(room).id : tied[0];
      }
      changePhase(room, 'consequences');
    }
  }
}, 1000);

server.listen(port, '0.0.0.0', () => console.log(`Pactos de ceniza is ready at http://localhost:${port}`));
